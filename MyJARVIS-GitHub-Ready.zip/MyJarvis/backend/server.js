import "dotenv/config";
import express from "express";
import cors from "cors";
import OpenAI from "openai";

const app = express();
const port = Number(process.env.PORT || 3000);

if (!process.env.OPENAI_API_KEY) {
  console.error("Missing OPENAI_API_KEY. Create backend/.env from .env.example.");
  process.exit(1);
}

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

app.use(cors());
app.use(express.json({ limit: "64kb" }));

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "myjarvis-backend" });
});

app.post("/chat", async (req, res) => {
  try {
    const message = typeof req.body?.message === "string"
      ? req.body.message.trim()
      : "";

    if (!message) {
      return res.status(400).json({ error: "message is required" });
    }

    if (message.length > 4000) {
      return res.status(400).json({ error: "message is too long" });
    }

    const response = await client.responses.create({
      model: "gpt-5.6-luna",
      instructions:
        "You are MyJARVIS, a helpful, concise Android assistant. " +
        "Reply naturally. Use simple language unless the user asks for detail.",
      input: [
        {
          role: "user",
          content: message
        }
      ]
    });

    res.json({
      reply: response.output_text || "I could not generate a reply."
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error: "AI request failed"
    });
  }
});

app.listen(port, "0.0.0.0", () => {
  console.log(`MyJARVIS backend running on port ${port}`);
});
