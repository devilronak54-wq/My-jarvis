package com.myjarvis.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch
import java.util.Locale

data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    JarvisScreen { speak(it) }
                }
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
        }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun JarvisScreen(onSpeak: (String) -> Unit) {
    val context = LocalContext.current
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    val messages = remember {
        mutableStateListOf(
            ChatMessage("Hello! I am MyJARVIS. Type or speak something.", false)
        )
    }
    val scope = rememberCoroutineScope()

    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val text = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()

        if (!text.isNullOrBlank()) input = text
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startSpeech(speechLauncher)
    }

    fun send() {
        val text = input.trim()
        if (text.isEmpty() || loading) return

        messages.add(ChatMessage(text, true))
        input = ""
        loading = true

        scope.launch {
            try {
                val reply = if (looksLikeCalculation(text)) {
                    calculate(text)
                } else {
                    ApiProvider.api.chat(ChatRequest(text)).reply
                }

                messages.add(ChatMessage(reply, false))
                onSpeak(reply)
            } catch (_: Exception) {
                messages.add(
                    ChatMessage(
                        "Connection error. Check the backend and BASE_URL.",
                        false
                    )
                )
            } finally {
                loading = false
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("MyJARVIS", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Your Android AI assistant",
            Modifier.padding(bottom = 12.dp)
        )

        LazyColumn(
            Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages) { message ->
                Text(
                    if (message.fromUser) "You: ${message.text}"
                    else "JARVIS: ${message.text}"
                )
            }
            if (loading) item { Text("JARVIS is thinking...") }
        }

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Ask JARVIS...") }
            )
            Button(onClick = { send() }) {
                Text("Send")
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(onClick = {
                val granted = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED

                if (granted) {
                    startSpeech(speechLauncher)
                } else {
                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            }) {
                Text("Mic")
            }

            Button(onClick = {
                input = ""
            }) {
                Text("Clear")
            }
        }

        Text(
            if (loading) "Please wait..." else "Ready",
            Modifier.padding(top = 8.dp)
        )
    }
}

private fun startSpeech(
    launcher: androidx.activity.result.ActivityResultLauncher<Intent>
) {
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(
            RecognizerIntent.EXTRA_LANGUAGE_MODEL,
            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
        )
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
    }
    launcher.launch(intent)
}

private fun looksLikeCalculation(text: String): Boolean {
    val cleaned = text.lowercase(Locale.getDefault())
    return cleaned.startsWith("calculate ") ||
        cleaned.matches(Regex("""\s*\d+(\s*[\+\-\*\/]\s*\d+)+\s*"""))
}

private fun calculate(text: String): String {
    val expression = text
        .replace(Regex("(?i)^calculate\\s*"), "")
        .replace(" ", "")

    val match = Regex("""^(\d+(?:\.\d+)?)([\+\-\*/])(\d+(?:\.\d+)?)$""")
        .matchEntire(expression)
        ?: return "I can currently calculate simple two-number expressions."

    val a = match.groupValues[1].toDouble()
    val op = match.groupValues[2]
    val b = match.groupValues[3].toDouble()

    val answer = when (op) {
        "+" -> a + b
        "-" -> a - b
        "*" -> a * b
        "/" -> if (b == 0.0) return "Division by zero is not allowed." else a / b
        else -> return "Unsupported operation."
    }

    return "The answer is $answer"
}
