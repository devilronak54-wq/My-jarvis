package com.myjarvis.app

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST

data class ChatRequest(val message: String)
data class ChatResponse(val reply: String)

interface JarvisApi {
    @POST("chat")
    suspend fun chat(@Body request: ChatRequest): ChatResponse
}

/*
 * LOCAL DEVELOPMENT:
 * Replace this with the address of your backend.
 *
 * Android emulator -> http://10.0.2.2:3000/
 * Physical phone -> http://YOUR_COMPUTER_LAN_IP:3000/
 *
 * Production -> use an HTTPS URL.
 */
object ApiProvider {
    private const val BASE_URL = "http://10.0.2.2:3000/"

    val api: JarvisApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(JarvisApi::class.java)
    }
}
