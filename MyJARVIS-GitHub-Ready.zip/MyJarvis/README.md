# MyJARVIS

A beginner-friendly Android AI assistant starter project.

## Architecture

Android app -> your Node.js backend -> OpenAI Responses API

The OpenAI API key stays on the backend and is never placed in the Android app or GitHub repository.

## Features in this starter

- Text chat with an AI assistant
- Speech-to-text using Android SpeechRecognizer
- Text-to-speech using Android TextToSpeech
- Simple calculator command (`calculate 25 * 4`)
- Clean separation between Android app and backend
- `.env` used for the backend secret

## 1. Backend

Requirements: Node.js 20+

```bash
cd backend
npm install
cp .env.example .env
```

Put your OpenAI API key in `.env`:

```env
OPENAI_API_KEY=your_key_here
PORT=3000
```

Start it:

```bash
npm start
```

The server listens on `http://0.0.0.0:3000`.

For a real phone, the Android app must be able to reach the backend. Replace `BASE_URL` in the Android code with your computer/server's reachable address, for example:

```text
http://192.168.1.10:3000/
```

Do not commit `.env`.

## 2. Android

Open the `android` folder in Android Studio.

For a physical phone, make sure the phone and backend computer are on a network that can reach each other.

If you use plain HTTP for local development, the app has cleartext traffic enabled. For production, use HTTPS and disable cleartext traffic.

## 3. GitHub

Commit the project, but never commit:

- `backend/.env`
- API keys
- passwords
- private certificates

The included `.gitignore` protects the common secret files.

## Next upgrades

- Wake-word / always-listening mode
- Web search
- Conversation memory
- App-opening commands
- Weather
- Reminders
- Custom JARVIS personality
